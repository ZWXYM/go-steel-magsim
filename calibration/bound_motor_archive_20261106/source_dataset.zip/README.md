# 单数据集工程分析包

数据集：v8_2_bound_archive

版本：V8_2_bound_report_CSV_v1；协议：v8_2_cycle1

作者V8_2同报告绑定CSV补齐集合；23ZDKH75明确使用clean_resolved2，报告与final字节一致。保留原6案及异常，不新增独立样品，不认证48插片损耗/RD-TD或稳态最终排名。

保存条目6项，其中5项通过各自原判据。

metrics.csv保留所有条目及原始异常；accepted_metrics.csv只列原input_accepted=true的条目，不改变门限。native_csv_metrics.csv只列官方CSV来源且通过原判据的条目；V8_1为历史处理/估算，不能因此进入该原生子集。data_usage.json说明使用范围。原生CSV来源与原数值判据逐行核对；报告估算、周期范围及损耗边界保持，不视为独立实测认证。 补齐版包含原归档的重复案例，23ZDKH75按同报告合同读取clean_resolved2，原final归档不变。

reference_choices.csv列页面可选基准，其中可能含原baseline/control以及metrics.csv中的条目，不能另算作独立实验。

来源文件按原字节保留在sources/，每个文件的哈希及未包含原因见source_snapshot.json。未附带的官方CSV不从其他版本补齐。不同数据集/模型/协议不得混作同一次材料排名；铁损与效率仍按原工程报告/估算范围使用，不是新损耗校准或实测认证。

本包只读取已保存数据，不新增筛选、预测、原生求解或排名，不修改原文件。
